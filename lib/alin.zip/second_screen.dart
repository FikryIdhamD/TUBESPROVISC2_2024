// second_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'third_screen.dart';

class SecondScreen extends StatefulWidget {
  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  String selectedHospital = "Mereun Hospital Bandung";
  String selectedSpeciality = "Cardiologist"; // Updated variable
  String selectedDay = "Sunday";

  List<String> daysList = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];

  List<String> specialitiesList = [
    "Cardiologist",
    "Dermatologist",
    "Neurologist",
    "Oncologist",
    "Pediatrician",
    "Psychiatrist",
    "Surgeon"
  ];

  List<String> hospitalsList = [
    "Mereun Hospital Bandung",
    "Mereun Hospital Jakarta",
    "Mereun Hospital Bekasi"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.3,
              child: ClipPath(
                clipper: OvalTopClipper(),
                child: Container(
                  color: Color(0xFF0B8FAC),
                  child: Center(
                    child: Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                        Text(
                          'Book a new appointment',
                          style: GoogleFonts.poppins(
                            textStyle: Theme.of(context).textTheme.headline6,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "All Hospitals*",
                      style: GoogleFonts.poppins(
                        textStyle: Theme.of(context).textTheme.subtitle1,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      child: DropdownButton<String>(
                        onChanged: (value) {
                          setState(() {
                            selectedHospital = value!;
                          });
                        },
                        value: selectedHospital,
                        items: hospitalsList
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              value,
                              style: GoogleFonts.poppins(),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "All Specialities*",
                      style: GoogleFonts.poppins(
                        textStyle: Theme.of(context).textTheme.subtitle1,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      child: DropdownButton<String>(
                        onChanged: (value) {
                          setState(() {
                            selectedSpeciality =
                                value!; // Update selectedSpeciality
                          });
                        },
                        value: selectedSpeciality,
                        items: specialitiesList
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              value,
                              style: GoogleFonts.poppins(),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "All Days*",
                      style: GoogleFonts.poppins(
                        textStyle: Theme.of(context).textTheme.subtitle1,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      width: double.infinity,
                      child: DropdownButton<String>(
                        onChanged: (value) {
                          setState(() {
                            selectedDay = value!;
                          });
                        },
                        value: selectedDay,
                        items: daysList
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              value,
                              style: GoogleFonts.poppins(),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: 164,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => ThirdScreen(
                                    selectedSpeciality: selectedSpeciality),
                              ),
                            );
                          },
                          child: Text("Next"),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class OvalTopClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height * 0.7);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height * 0.7);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return false;
  }
}
