import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'second_screen.dart'; // Import the NextPage
import 'main.dart'; 

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int? selectedPatientIndex;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            color: Colors.white,
          ),
          ClipPath(
            clipper: OvalTopClipper(),
            child: Container(
              height: MediaQuery.of(context).size.height * 0.3,
              color: Color(0xFF0B8FAC), // Warna oval
              child: Center(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    double fontSize = constraints.maxWidth *
                        0.05; // Menggunakan persentase lebar layar untuk menentukan ukuran font
                    return Text(
                      'Pilih Pasien',
                      style: GoogleFonts.poppins(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: fontSize, // Mengatur font menjadi Poppins
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top,
            left: 8.0,
            child: IconButton(
              icon: Icon(Icons.close),
              color: Colors.white,
              onPressed: () {
                Navigator.push(context,
                MaterialPageRoute(builder: (context) => Home()));// Tindakan ketika tombol X ditekan
              },
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.3,
            left: 0,
            right: 0,
            bottom: MediaQuery.of(context).size.height *
                0.1, // Adjusted to accommodate the button
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              children: [
                Text(
                  'MYSELF',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                ContentBox(
                  name: 'Marvel R- My Self',
                  date: '24 December 2023',
                  phoneNumber: '+62-8123456789',
                  isSelected: selectedPatientIndex == 0,
                  onSelect: (bool isSelected) {
                    setState(() {
                      selectedPatientIndex = isSelected ? 0 : null;
                    });
                  },
                ),
                SizedBox(height: 10),
                Text(
                  'OTHERS',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 10),
                ContentBox(
                  name: 'Mohammad Faridz',
                  date: '21 September 2021',
                  phoneNumber: '+62-8123456789',
                  isSelected: selectedPatientIndex == 1,
                  onSelect: (bool isSelected) {
                    setState(() {
                      selectedPatientIndex = isSelected ? 1 : null;
                    });
                  },
                ),
                SizedBox(height: 10),
                ContentBox(
                  name: 'Fikri Idham',
                  date: '29 February 2003',
                  phoneNumber: '+62-8123456789',
                  isSelected: selectedPatientIndex == 2,
                  onSelect: (bool isSelected) {
                    setState(() {
                      selectedPatientIndex = isSelected ? 2 : null;
                    });
                  },
                ),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: EdgeInsets.all(16),
              color: Colors.white,
              child: ElevatedButton(
                onPressed: () {
                  // Handle next button press
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            SecondScreen()), // Navigate to NextPage
                  );
                },
                child: Text(
                  'Next',
                  style: GoogleFonts.poppins(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ContentBox extends StatelessWidget {
  final String name;
  final String date;
  final String phoneNumber;
  final bool isSelected;
  final Function(bool)? onSelect;

  const ContentBox({
    Key? key,
    required this.name,
    required this.date,
    required this.phoneNumber,
    this.isSelected = false,
    this.onSelect,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onSelect != null) {
          onSelect!(true);
        }
      },
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? Colors.blue[100] : Colors.grey[200],
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(date),
                  SizedBox(height: 8),
                  Text(phoneNumber),
                ],
              ),
            ),
            Radio(
              value: isSelected,
              groupValue: true,
              onChanged: (bool? value) {
                if (onSelect != null) {
                  onSelect!(value!);
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

class OvalTopClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height * 0.7);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height * 0.7);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return false;
  }
}
