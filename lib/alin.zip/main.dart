import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'appointments.dart';
import 'records.dart';
import 'login.dart';
import 'Profile.dart';
import 'emergency.dart';
import 'notification.dart';
import 'articles.dart';
import 'first_screen.dart';
import 'package:flutter/gestures.dart';
import 'transactions.dart';
//import 'payment.dart';
import 'Onlineconsultation.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Home(),
      debugShowCheckedModeBanner: false, // Remove the debug banner
    );
  }
}

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Listarticles articles = Listarticles();

  int _selectedIndex = 0; // untuk penanda tombol bottom navigation

  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);

  String selectedOption1 =
      'History'; // Penanda tombol history dan scheduled Default option is 'History' // Appointment
  String selectedOption2 =
      'Myself'; // Penanda tombol myself dan others Default option is 'myself' // record
  String selectedOption3 =
      'History'; // Penanda tombol history dan unpaid Default option is 'history' // transaction
  @override
  Widget build(BuildContext context) {
    List<AppointmentItem> historyList = [
      AppointmentItem(
        date: '15 Jan 2022, 15:30',
        title: 'Finished Appointment 1',
        status: 'Appointment Completed',
        onPressed: () {},
      ),
      AppointmentItem(
        date: '16 Jan 2022, 10:00',
        title: 'Finished Appointment 2',
        status: 'Appointment Completed',
        onPressed: () {},
      ),
      AppointmentItem(
        date: '17 Jan 2022, 11:30',
        title: 'Finished Appointment 3',
        status: 'Appointment Completed',
        onPressed: () {},
      ),
      AppointmentItem(
        date: '15 Jan 2022, 15:30',
        title: 'Finished Appointment 1',
        status: 'Appointment Completed',
        onPressed: () {},
      ),
      AppointmentItem(
        date: '16 Jan 2022, 10:00',
        title: 'Finished Appointment 2',
        status: 'Appointment Completed',
        onPressed: () {},
      ),
      AppointmentItem(
        date: '17 Jan 2022, 11:30',
        title: 'Finished Appointment 3',
        status: 'Appointment Completed',
        onPressed: () {},
      ),
    ];

    List<AppointmentItem> scheduledList = [
      AppointmentItem(
        date: '20 Jan 2022, 14:00',
        title: 'Scheduled Appointment 1',
        status: 'Scheduled',
        onPressed: () {},
      ),
      AppointmentItem(
        date: '22 Jan 2022, 09:30',
        title: 'Scheduled Appointment 2',
        status: 'Scheduled',
        onPressed: () {},
      ),
    ];

    List<RecordsItem> OthersList = [
      RecordsItem(
        date: '15 Jan 2022, 15:30',
        patient: 'Elizabeth Rose Smith',
        doctor: 'Dr. Emily Johnson',
        spesialis: 'Cardiology',
        onPressed: () {},
      ),
      RecordsItem(
        date: '16 Jan 2022, 10:00',
        patient: 'Adam Christopher Brown',
        doctor: 'Dr. Michael Brown',
        spesialis: 'Dermatology',
        onPressed: () {},
      ),
      RecordsItem(
        date: '17 Jan 2022, 11:30',
        patient: 'Robert William Johnson',
        doctor: 'Dr. Sarah Clark',
        spesialis: 'Orthopedics',
        onPressed: () {},
      ),
    ];

    List<RecordsItem> MyselfList = [
      RecordsItem(
        date: '20 Jan 2022, 14:00',
        patient: 'Mary Anne White',
        doctor: 'Dr. David Lee',
        spesialis: 'Pediatrics',
        onPressed: () {},
      ),
      RecordsItem(
        date: '22 Jan 2022, 09:30',
        patient: 'Mary Anne White',
        doctor: 'Dr. Jennifer Taylor',
        spesialis: 'Oncology',
        onPressed: () {},
      ),
    ];

    List<TransactionItem> historyList2 = [
      TransactionItem(
        date: '20 Jan 2022, 14:00',
        title: 'Online Consultation (chat)',
        status: 'Payment Completed',
        onPressed: () {},
      ),
      TransactionItem(
        date: '22 Jan 2022, 09:30',
        title: 'Online Consultation (call)',
        status: 'Payment Completed',
        onPressed: () {},
      ),
    ];

    List<TransactionItem> unpaidList = [
      TransactionItem(
        date: '20 Jan 2024, 14:00',
        title: 'Online Consultation (chat)',
        status: 'Payment Incompleted',
        onPressed: () {},
      ),
      TransactionItem(
        date: '22 Jan 2024, 09:30',
        title: 'Online Consultation (call)',
        status: 'Payment Incompleted',
        onPressed: () {},
      ),
    ];

    List<Widget> _widgetOptions = <Widget>[
      // Widget untuk halaman Home
      SingleChildScrollView(
        child: Stack(
          children: [
            Column(
              children: [
                // Banner Image
                Image.asset(
                  'assets/banner.png',
                  width: MediaQuery.of(context).size.width,
                  fit: BoxFit.cover,
                ),
                const SizedBox(height: 50),
                // Adjust the left padding as needed
                Align(
                  alignment: Alignment.center,
                  child: Wrap(
                    spacing: 35.0, // Jarak horizontal antar widget
                    children: [
                      _buildSquareButtonWithText(
                        context,
                        'Book\nAppointment',
                        HomeScreen(),
                        'assets/Book-Btn.png',
                      ),

                      _buildSquareButtonWithText(
                        context,
                        'Articles',
                        ArticlePage(),
                        'assets/News-Btn.png',
                      ),

                      // _buildSquareButtonWithText(
                      //     'Lab Tests', 'lab tests page', 'assets/Lab-Btn.png'),
                      _buildSquareButtonWithText(
                        context,
                        'Online\nConsultation',
                        ConsultationScreen(),
                        'assets/Consultation-Btn.png',
                      ),
                    ],
                  ),
                ),

                // Title sebelum gridview artikel
                const SizedBox(height: 20.0),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Latest Article',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 12.0),
                // Artikel menggunakan ListView
                Container(
                  height: 160, // Specify a fixed height
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: articles.articles
                        .length, // Ganti dengan jumlah artikel yang ada
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ArticleDetailPage(
                                  article: articles.articles[index]),
                            ),
                          );
                        },
                        child: Container(
                          width: 250,
                          margin: const EdgeInsets.symmetric(horizontal: 8.0),
                          decoration: BoxDecoration(
                            color: const Color.fromRGBO(34, 86, 108, 1),
                            borderRadius: BorderRadius.circular(16.0),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(16.0),
                                  topRight: Radius.circular(16.0),
                                ),
                                child: Image.network(
                                  articles.articles[index]
                                      .imageUrl, // Gunakan URL gambar dari artikel
                                  height: 100,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      articles.articles[index]
                                          .title, // Tampilkan judul artikel
                                      style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(height: 4.0),
                                    Text(
                                      articles.articles[index]
                                          .content, // Tampilkan konten artikel
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w700,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            Positioned(
              left: 16.0, // Adjust left position as needed
              top: 180.0, // Adjust top position as needed
              child: GestureDetector(
                onTap: () {
                  // Tambahkan fungsi untuk menangani ketika container diklik
                },
                child: Container(
                  width: MediaQuery.of(context).size.width - 32,
                  height: 60.0, // Atur tinggi sesuai kebutuhan Anda
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  margin: const EdgeInsets.symmetric(vertical: 8.0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8.0),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      RichText(
                        text: TextSpan(
                          text: 'Hi, ',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 16.0,
                            fontWeight: FontWeight
                                .bold, // Membuat teks menjadi tebal (bold)
                          ),
                          children: [
                            TextSpan(
                              text: 'Login',
                              style: TextStyle(
                                color: const Color.fromARGB(
                                    255, 0, 0, 0), // Warna teks "Login"
                                decoration: TextDecoration.underline,
                              ),
                              // Handle ketika "Login" diklik di sini
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Login()),
                                  );
                                },
                            ),
                            TextSpan(
                              text: ' to access more features.',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          // Tambahkan fungsi untuk menangani ketika ikon ambulance diklik
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Emergency()),
                          );
                        },
                        child: Container(
                          padding: EdgeInsets.all(8.0),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors
                                .white, // Warna latar belakang ikon ambulance
                          ),
                          child: Icon(
                            Icons.local_hospital,
                            size: 30,
                            color: Colors.red, // Warna ikon ambulance
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

      // Widget untuk halaman Appointments
      Appointments(
        selectedOption: selectedOption1,
        onOptionChanged: (newOption) {
          setState(() {
            selectedOption1 = newOption;
          });
        },
        appointmentList:
            selectedOption1 == 'History' ? historyList : scheduledList,
      ),

      // Widget untuk halaman Records
      Records(
        selectedOption: selectedOption2,
        onOptionChanged: (newOption) {
          setState(() {
            selectedOption2 = newOption;
          });
        },
        RecordsList: selectedOption2 == 'Myself' ? MyselfList : OthersList,
      ),

      // Widget untuk halaman Transactions
      Transactions(
        selectedOption: selectedOption3,
        onOptionChanged: (newOption) {
          setState(() {
            selectedOption3 = newOption;
          });
        },
        TransactionList:
            selectedOption3 == 'History' ? historyList2 : unpaidList,
      ),
    ];

    return DefaultTextStyle(
      style: GoogleFonts.poppins(), // Set default text style to Poppins
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(65.0), // Tinggi header baru
          child: Stack(
            children: [
              // Home Page AppBar
              if (_selectedIndex == 0)
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      bottomLeft: const Radius.circular(20.0),
                      bottomRight: const Radius.circular(20.0),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 5.0,
                        offset: const Offset(0.0, 4.0),
                      ),
                    ],
                  ),
                  child: AppBar(
                    actions: [
                      IconButton(
                        padding: const EdgeInsets.only(right: 10.0),
                        iconSize: 34,
                        icon: const Icon(Icons.notifications),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => NotificationPage()),
                          );
                        },
                      ),
                      IconButton(
                        padding: const EdgeInsets.only(right: 20.0),
                        iconSize: 34,
                        icon: const Icon(Icons.account_circle),
                        onPressed: () {
                          // Handle profile button tap
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Profile()));
                        },
                      ),
                    ],
                    leading: Padding(
                      padding: const EdgeInsets.only(left: 20.0),
                      child: FittedBox(
                        fit: BoxFit.cover,
                        child: Image.asset(
                          'assets/hospital_logo.png',
                          width: 100,
                          height: 100,
                        ),
                      ),
                    ),
                    backgroundColor: Colors.transparent,
                    elevation: 0.0,
                  ),
                ),

              // Selected Tab AppBar
              if (_selectedIndex != 0)
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      bottomLeft: const Radius.circular(20.0),
                      bottomRight: const Radius.circular(20.0),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 5.0,
                        offset: const Offset(0.0, 4.0),
                      ),
                    ],
                  ),
                  child: _buildAppBar(
                    _selectedIndex == 1
                        ? 'Appointments'
                        : _selectedIndex == 2
                            ? 'Medical Records'
                            : _selectedIndex == 3
                                ? 'Transactions'
                                : '',
                  ),
                ),
            ],
          ),
        ),
        body: Column(
          children: [
            if (_selectedIndex == 0) const SizedBox(height: 15.0),
            if (_selectedIndex != 0)
              const SizedBox(
                  height:
                      60.0), // Tambahkan SizedBox di sini dengan tinggi yang diinginkan
            Expanded(
              child: Center(
                child: _widgetOptions.elementAt(_selectedIndex),
              ),
            ),
          ],
        ),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 5.0,
                offset: const Offset(0.0, -4.0),
              ),
            ],
          ),
          child: BottomNavigationBar(
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.calendar_today),
                label: 'Appointments',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.assignment),
                label: 'Records',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.account_balance_wallet),
                label: 'Transactions',
              ),
            ],
            currentIndex: _selectedIndex,
            selectedItemColor: Colors.black,
            unselectedItemColor: Colors.grey,
            onTap: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            type: BottomNavigationBarType.fixed,
            showSelectedLabels: true,
            showUnselectedLabels: true,
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar(String title) {
    return AppBar(
      titleSpacing: 25.0,
      title: Text(
        title,
        style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
      ),
      backgroundColor: Colors.white,
      elevation: 0.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          bottom: Radius.circular(30), // Sesuaikan nilai sesuai keinginan Anda
        ),
      ),
    );
  }
}

Widget _buildSquareButtonWithText(
  BuildContext context,
  String buttonText,
  Widget destinationPage,
  String imagePath,
) {
  return Column(
    children: [
      InkWell(
        onTap: () {
          // Navigate to the specified page
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => destinationPage,
            ),
          );
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: Image.asset(
            imagePath,
            height: 65,
            width: 65,
            fit: BoxFit.cover,
          ),
        ),
      ),
      const SizedBox(height: 4.0),
      Text(
        buttonText,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Colors.black,
        ),
      ),
    ],
  );
}
