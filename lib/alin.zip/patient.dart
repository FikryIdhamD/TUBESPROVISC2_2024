import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: PatientProfilePage(),
  ));
}

class PatientProfilePage extends StatefulWidget {
  @override
  _PatientProfilePageState createState() => _PatientProfilePageState();
}

class Patient {
  final String name;
  final String dateOfBirth;
  final String phoneNumber;

  Patient({required this.name, required this.dateOfBirth, required this.phoneNumber});
}

class ListPatient {
  List<Patient> patients = [];

  ListPatient() {
    this.patients = [
      Patient(
        name: 'John Doe',
        dateOfBirth: '24 Juni 1990',
        phoneNumber: '+621234567890',
      ),
      Patient(
        name: 'Jane Smith',
        dateOfBirth: '15 April 2001',
        phoneNumber: '+62987654321',
      ),
      Patient(
        name: 'Will Smack',
        dateOfBirth: '12 Desember 2003',
        phoneNumber: '+6281271310',
      ),
    ];
  }
}

class _PatientProfilePageState extends State<PatientProfilePage> {
  ListPatient patientList = ListPatient();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: AppBar(
          centerTitle: true,
          title: Text(
            'Patient Profile',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20.0),
              bottomRight: Radius.circular(20.0),
            ),
          ),
          leading: IconButton(
            icon: Icon(
              Icons.close,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
      ),
      body: Container(
        color: Colors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: ListView(
                padding: EdgeInsets.all(16.0),
                children: <Widget>[
                  Text(
                    'Myself:',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  _buildPatientContainer(patientList.patients[0], isMyself: true),
                  SizedBox(height: 16.0),
                  Text(
                    'Others:',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  for (var patient in patientList.patients.skip(1))
                    _buildPatientContainer(patient),
                ],
              ),
            ),
            SizedBox(height: 20.0),
            Container(
              height: 70,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        _addPatient();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF0B8FAC),
                      ),
                      child: Text(
                        'Add Other Profile',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20.0),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPatientContainer(Patient patient, {bool isMyself = false}) {
    return Container(
      padding: EdgeInsets.all(16.0),
      margin: EdgeInsets.symmetric(vertical: 8.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.0),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${patient.name}' +
                    (isMyself ? ' - Myself' : ''),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
              ),
              PopupMenuButton(
                itemBuilder: (BuildContext context) => <PopupMenuEntry>[
                  const PopupMenuItem(
                    child: Text('Edit'),
                    value: 'edit',
                  ),
                  const PopupMenuItem(
                    child: Text('Delete'),
                    value: 'delete',
                  ),
                ],
                onSelected: (value) {
                  if (value == 'edit') {
                    _editPatient(patient);
                  } else if (value == 'delete') {
                    _deletePatient(patient);
                  }
                },
              ),
            ],
          ),
          Text('${patient.dateOfBirth}'),
          Text('${patient.phoneNumber}'),
          SizedBox(
            height: 20.0,
          ),
          GestureDetector(
            onTap: () {
              _requestChangeData(patient);
            },
            child: Text(
              'Request Change Data',
              style: TextStyle(
                color: Colors.black54,
                decoration: TextDecoration.underline,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _addPatient() {
    setState(() {
      patientList.patients.add(Patient(
        name: 'New Patient',
        dateOfBirth: 'New Date',
        phoneNumber: 'New Phone Number',
      ));
    });
  }

  void _requestChangeData(Patient patient) {
    print('Requesting change data...');
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ChangeDataPage(patient: patient)),
    );
  }

  void _editPatient(Patient patient) {
    print('Editing patient: ${patient.name}');
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ChangeDataPage(patient: patient)),
    );
  }

  void _deletePatient(Patient patient) {
    print('Deleting patient: ${patient.name}');
    setState(() {
      patientList.patients.remove(patient);
    });
  }
}

class ChangeDataPage extends StatelessWidget {
  final Patient patient;

  ChangeDataPage({required this.patient});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(60.0),
        child: AppBar(
          centerTitle: true,
          title: Text(
            'Change Data',
            style: TextStyle(
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20.0),
              bottomRight: Radius.circular(20.0),
            ),
          ),
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                initialValue: patient.name,
                decoration: InputDecoration(
                  labelText: 'Nama Lengkap',
                ),
                onChanged: (value) {
                  // Implement your logic for updating patient's name
                },
              ),
              SizedBox(height: 10),
              TextFormField(
                initialValue: patient.dateOfBirth,
                decoration: InputDecoration(
                  labelText: 'Tanggal Lahir',
                ),
                onChanged: (value) {
                  // Implement your logic for updating patient's date of birth
                },
              ),
              SizedBox(height: 10),
              // Add dropdown for identity card type
              // Add field for uploading identity card photo
              // Add TextFormField for identity card number
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Implement your logic for saving changes
                },
                child: Text('Simpan Perubahan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
