// third_screen.dart
import 'package:flutter/material.dart';
import 'fourth_screen.dart';

class ThirdScreen extends StatefulWidget {
  final String selectedSpeciality;

  ThirdScreen({required this.selectedSpeciality});

  @override
  _ThirdScreenState createState() => _ThirdScreenState();
}

class _ThirdScreenState extends State<ThirdScreen> {
  final List<Map<String, String>> doctors = [
    {"name": "Dr. Rajesh Ipsum", "speciality": "Cardiologist"},
    {"name": "Dr. John Doe", "speciality": "Cardiologist"},
    {"name": "Dr. Jane Smith", "speciality": "Cardiologist"},
    {"name": "Dr. Emily Johnson", "speciality": "Dermatologist"},
    {"name": "Dr. Michael Brown", "speciality": "Dermatologist"},
    {"name": "Dr. Sarah Williams", "speciality": "Dermatologist"},
    {"name": "Dr. Alex Lee", "speciality": "Neurologist"},
    {"name": "Dr. Mary Johnson", "speciality": "Neurologist"},
    {"name": "Dr. David Smith", "speciality": "Neurologist"},
    {"name": "Dr. Jessica Brown", "speciality": "Oncologist"},
    {"name": "Dr. Christopher Lee", "speciality": "Oncologist"},
    {"name": "Dr. Jennifer Davis", "speciality": "Oncologist"},
    {"name": "Dr. Samantha Wilson", "speciality": "Pediatrician"},
    {"name": "Dr. William Martinez", "speciality": "Pediatrician"},
    {"name": "Dr. Olivia Garcia", "speciality": "Pediatrician"},
    {"name": "Dr. Daniel Miller", "speciality": "Psychiatrist"},
    {"name": "Dr. Hannah Rodriguez", "speciality": "Psychiatrist"},
    {"name": "Dr. Ethan Thompson", "speciality": "Psychiatrist"},
    {"name": "Dr. Sophia Moore", "speciality": "Surgeon"},
    {"name": "Dr. Noah White", "speciality": "Surgeon"},
    {"name": "Dr. Lily Adams", "speciality": "Surgeon"},
  ];

  List<Map<String, String>> filteredDoctors = [];

  // overide agar initial state/ tampilannya langsung menampilkan dokter yang telah difilter dari spesialis second_screen
  @override
  void initState() {
    super.initState();
    filterDoctors('');
  }

  // fungsi pencarian berdasarkan nama
  void filterDoctors(String query) {
    setState(() {
      if (query.isNotEmpty) {
        filteredDoctors = doctors
            .where((doctor) =>
                doctor['speciality']!
                    .toLowerCase()
                    .contains(widget.selectedSpeciality.toLowerCase()) &&
                doctor['name']!.toLowerCase().contains(query.toLowerCase()))
            .toList();
      } else if (widget.selectedSpeciality.isNotEmpty) {
        filteredDoctors = doctors
            .where((doctor) => doctor['speciality']!
                .toLowerCase()
                .contains(widget.selectedSpeciality.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Find Doctor',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              onChanged: (value) {
                filterDoctors(value);
              },
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search), // Icon search di sini
                labelText: 'Search',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredDoctors.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => FourthScreen(),
                      ),
                    );
                  },
                  child: DoctorProfileBox(
                    name: filteredDoctors[index]['name']!,
                    speciality: filteredDoctors[index]['speciality']!,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class DoctorProfileBox extends StatelessWidget {
  final String name;
  final String speciality;

  DoctorProfileBox({
    required this.name,
    required this.speciality,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
            width: 2.0,
          ),
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage(
              'https://img.icons8.com/clouds/100/medical-doctor.png',
            ),
            //radius: 30, // Adjust the size of the circle avatar
          ),
          title: Text(
            name,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: Text(
            speciality,
            style: TextStyle(
              fontFamily: 'Poppins',
            ),
          ),
        ),
      ),
    );
  }
}
