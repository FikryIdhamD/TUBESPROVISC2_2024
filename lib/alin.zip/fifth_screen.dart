import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:flutter_time_picker_spinner/flutter_time_picker_spinner.dart';

class FifthScreen extends StatefulWidget {
  @override
  _FifthScreenState createState() => _FifthScreenState();
}

class _FifthScreenState extends State<FifthScreen> {
  DateTime _selectedDate = DateTime.now();
  DateTime _selectedTime = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Choose Schedule'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Choose Date',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              _buildCalendar(),
              SizedBox(height: 16),
              _buildDoctorProfile(),
              SizedBox(height: 16),
              Text(
                'Chosen Schedule:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(
                'Date: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Time: ${_selectedTime.hour.toString().padLeft(2, '0')}:${_selectedTime.minute.toString().padLeft(2, '0')}',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 16),
              Align(
                alignment: Alignment.center,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.popUntil(context, ModalRoute.withName('/'));
                  },
                  child: Text('Book Now'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCalendar() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(),
        borderRadius: BorderRadius.circular(8.0),
      ),
      padding: EdgeInsets.all(8.0),
      child: SizedBox(
        height: 350,
        child: TableCalendar(
          firstDay: DateTime.now(),
          lastDay: DateTime.now().add(Duration(days: 365)),
          focusedDay: _selectedDate,
          selectedDayPredicate: (day) => isSameDay(_selectedDate, day),
          onDaySelected: (selectedDay, focusedDay) {
            setState(() {
              _selectedDate = selectedDay;
            });
            _showTimePickerSpinner();
          },
        ),
      ),
    );
  }

  Widget _buildDoctorProfile() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border.all(),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Dr. Rajesh Ipsum',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            Text('Cardiologist'),
          ],
        ),
      ),
    );
  }

  Future<void> _showTimePickerSpinner() async {
    final timePicked = await showDialog<TimeOfDay>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Pick a time'),
        content: TimePickerSpinner(
          is24HourMode: true,
          isShowSeconds: false,
          normalTextStyle: TextStyle(fontSize: 24, color: Colors.black),
          highlightedTextStyle: TextStyle(fontSize: 24, color: Colors.black),
          spacing: 50,
          itemHeight: 80,
          isForce2Digits: true,
          minutesInterval: 15,
          onTimeChange: (time) {
            setState(() {
              _selectedTime = DateTime(
                _selectedDate.year,
                _selectedDate.month,
                _selectedDate.day,
                time.hour,
                time.minute,
              );
            });
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK'),
          ),
        ],
      ),
    );

    if (timePicked != null) {
      setState(() {
        _selectedTime = DateTime(
          _selectedDate.year,
          _selectedDate.month,
          _selectedDate.day,
          timePicked.hour,
          timePicked.minute,
        );
      });
    }
  }
}
