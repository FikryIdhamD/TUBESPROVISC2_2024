import 'package:flutter/material.dart';
import 'package:stproject/main.dart';

void main() {
  runApp(MyApp());
}

class Article {
  final String title;
  final String imageUrl;
  final String content;

  Article({required this.title, required this.imageUrl, required this.content});
}

class Listarticles {
  List<Article> articles = [];

  Listarticles() {
    this.articles = [
      Article(
          title: "Bahaya Begadang",
          imageUrl:
              "https://d1bpj0tv6vfxyp.cloudfront.net/articles/333342_25-11-2020_11-49-50.jpeg",
          content:
              "Terlalu sering begadang membuat seseorang kurang tidur. Jika dilakukan sesekali saja tidak masalah. Namun jika terlalu sering, ada banyak sekali dampak kesehatan yang bisa saja terjadi. Beberapa di antaranya adalah penurunan daya ingat, berat badan, kehidupan seksual, serta kesehatan. Kurang tidur bukanlah hal yang bisa disepelekan begitu saja. Normalnya seseorang memiliki waktu tidur selama 7–9 jam per hari. Jika kurang, berikut ini bahaya yang akan muncul."),
      Article(
          title: "Kerja Cepat malah Mengahambat",
          imageUrl:
              "https://d1bpj0tv6vfxyp.cloudfront.net/articles/811714_28-10-2020_9-30-20.jpeg",
          content:
              "Banyak orang yang mengira bahwa multitasking adalah cara yang bagus untuk menyelesaikan banyak hal sekaligus. Melansir dari Verywell Mind, penelitian telah menunjukkan bahwa otak ternyata tidak sebaik yang banyak orang pikirkan tentang multitasking. Faktanya, beberapa peneliti menyebutkan bahwa multitasking malah dapat mengurangi produktivitas sebanyak 40 persen. Kelihatannya, multitasking memang ampuh untuk menyelesaikan banyak hal pada waktu yang sama. Padahal, kamu sebenarnya hanya melakukan tugas dengan cepat dan mengalihkan perhatian dari satu hal ke hal berikutnya. Beralih dari satu tugas ke tugas lainnya justru bisa menyulitkan kamu dan bahkan memperlambat pekerjaan. "),
      Article(
          title: "Kerja Cepat malah Mengahambat",
          imageUrl:
              "https://d1bpj0tv6vfxyp.cloudfront.net/articles/811714_28-10-2020_9-30-20.jpeg",
          content:
              "Banyak orang yang mengira bahwa multitasking adalah cara yang bagus untuk menyelesaikan banyak hal sekaligus. Melansir dari Verywell Mind, penelitian telah menunjukkan bahwa otak ternyata tidak sebaik yang banyak orang pikirkan tentang multitasking. Faktanya, beberapa peneliti menyebutkan bahwa multitasking malah dapat mengurangi produktivitas sebanyak 40 persen. Kelihatannya, multitasking memang ampuh untuk menyelesaikan banyak hal pada waktu yang sama. Padahal, kamu sebenarnya hanya melakukan tugas dengan cepat dan mengalihkan perhatian dari satu hal ke hal berikutnya. Beralih dari satu tugas ke tugas lainnya justru bisa menyulitkan kamu dan bahkan memperlambat pekerjaan. "),
      // Tambahkan artikel lain di sini
    ];
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Article Search',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: ArticlePage(),
    );
  }
}

class ArticlePage extends StatefulWidget {
  @override
  _ArticlePageState createState() => _ArticlePageState();
}

class _ArticlePageState extends State<ArticlePage> {
  late Listarticles articles = Listarticles();

  List<Article> filteredArticles = [];

  @override
  void initState() {
    super.initState();
    filteredArticles = articles.articles;
  }

  void filterArticles(String query) {
    setState(() {
      filteredArticles = articles.articles
          .where((article) =>
              article.title.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Articles',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => Home()));// Tambahkan fungsi untuk menutup fitur pencarian di sini
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: TextField(
                onChanged: (value) => filterArticles(value),
                decoration: InputDecoration(
                  hintText: 'Search Articles',
                  suffixIcon: Icon(Icons.search),
                ),
              ),
            ),
            SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: filteredArticles.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ArticleDetailPage(
                              article: filteredArticles[index]),
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10.0),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset:
                                  Offset(0, 3), // changes position of shadow
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Gambar
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10.0),
                              child: Container(
                                width: 120,
                                height: 120,
                                child: Image.network(
                                  filteredArticles[index].imageUrl,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            SizedBox(width: 8),
                            // Judul dan teks
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    filteredArticles[index].title,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    filteredArticles[index].content,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ArticleDetailPage extends StatelessWidget {
  final Article article;

  ArticleDetailPage({required this.article});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Tombol kembali pada AppBar
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => ArticlePage()));
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Judul artikel
          Padding(
            padding: const EdgeInsets.only(bottom: 16.0, left: 20.0),
            child: Text(
              article.title,
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
          ),
          // Gambar artikel
          FractionallySizedBox(
            widthFactor: 1.0,
            child: Image.network(
              article.imageUrl,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(height: 16),
          // Konten artikel
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 35.0),
            child: Text(
              article.content,
              style: TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}
